'use server';
/**
 * @fileOverview A Genkit flow for handling voice commands to control music playback and search in Nova Music.
 *
 * - handleVoiceCommands - A function that interprets user voice commands into structured music control actions.
 * - VoiceCommandInput - The input type for the handleVoiceCommands function.
 * - MusicControlAction - The return type for the handleVoiceCommands function, representing the action to be taken.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const VoiceCommandInputSchema = z.string().describe('The user\'s voice command for music control.');
export type VoiceCommandInput = z.infer<typeof VoiceCommandInputSchema>;

const MusicControlActionSchema = z.object({
  action: z.enum(['search', 'play', 'pause', 'resume', 'skip', 'setVolume', 'playMoodMusic', 'createPlaylist', 'unhandled']).describe('The action to perform (e.g., search, play, skip, pause, unhandled).'),
  type: z.enum(['song', 'artist', 'album', 'playlist', 'genre', 'mood', 'undefined']).optional().describe('The type of item to search or play (e.g., song, artist, album).'),
  query: z.string().optional().describe('The search query for songs, artists, or albums.'),
  itemId: z.string().optional().describe('The ID of the item to play. This would typically be resolved after a search action.'),
  volumeLevel: z.number().int().min(0).max(100).optional().describe('The desired volume level (0-100).'),
  mood: z.string().optional().describe('The mood for which to play music (e.g., "relaxing", "upbeat").'),
  playlistName: z.string().optional().describe('The name of the playlist to create.'),
}).describe('A structured representation of a music control action derived from a voice command.');
export type MusicControlAction = z.infer<typeof MusicControlActionSchema>;

const musicControlTool = ai.defineTool(
  {
    name: 'musicControl',
    description: 'Provides structured music control commands to the Nova Music application based on user voice input. Use this tool to search for music, control playback, or manage playlists.',
    inputSchema: MusicControlActionSchema,
    outputSchema: MusicControlActionSchema,
  },
  async (input) => {
    // This tool is designed to be called by the LLM to structure its output.
    // The client application will then execute the returned action.
    return input;
  }
);

const promptContent = `You are a helpful AI assistant for Nova Music. Your task is to interpret user voice commands and convert them into structured music control actions using the available tool. Always try to use the 'musicControl' tool to respond.

If the user asks to search for a song, artist, album, or playlist, use the 'musicControl' tool with 'action: "search"'.
If the user asks to play a specific song/artist/album, use 'action: "search"' first to identify, or 'action: "play"' if an ID is provided. The client application will handle resolving the ID after a search.
If the user wants to skip the current song, use 'action: "skip"'.
If the user wants to pause playback, use 'action: "pause"'.
If the user wants to resume playback, use 'action: "resume"'.
If the user asks to set the volume, use 'action: "setVolume"' with the 'volumeLevel'.
If the user asks to play music based on a mood, use 'action: "playMoodMusic"' with the 'mood'.
If the user asks to create a playlist, use 'action: "createPlaylist"' with the 'playlistName'.

If the command cannot be interpreted as a specific music control action, you should still attempt to call the 'musicControl' tool with 'action: "search"' and the full command as the 'query', or use 'action: "unhandled"' if no relevant action can be inferred at all.

Here are some examples of user commands and the expected tool calls:
- User: "Play Bohemian Rhapsody by Queen"
- Tool Call: {"action": "search", "query": "Bohemian Rhapsody by Queen", "type": "song"}

- User: "Skip this song"
- Tool Call: {"action": "skip"}

- User: "Pause music"
- Tool Call: {"action": "pause"}

- User: "Resume playback"
- Tool Call: {"action": "resume"}

- User: "Search for artists named Adele"
- Tool Call: {"action": "search", "query": "Adele", "type": "artist"}

- User: "Play something relaxing"
- Tool Call: {"action": "playMoodMusic", "mood": "relaxing"}

- User: "Set volume to 50"
- Tool Call: {"action": "setVolume", "volumeLevel": 50}

- User: "Create a playlist named workout jams"
- Tool Call: {"action": "createPlaylist", "playlistName": "workout jams"}

User Voice Command: `;

const handleVoiceCommandsFlow = ai.defineFlow(
  {
    name: 'handleVoiceCommandsFlow',
    inputSchema: VoiceCommandInputSchema,
    outputSchema: MusicControlActionSchema,
  },
  async (voiceCommand) => {
    const response = await ai.generate({
      model: 'googleai/gemini-2.5-flash',
      prompt: promptContent + voiceCommand,
      tools: [musicControlTool],
      config: {
        safetySettings: [
          {
            category: 'HARM_CATEGORY_DANGEROUS_CONTENT',
            threshold: 'BLOCK_NONE',
          },
        ],
      },
    });

    if (response.toolCalls && response.toolCalls.length > 0) {
      const toolCall = response.toolCalls[0];
      if (toolCall.name === 'musicControl') {
        return toolCall.args as MusicControlAction;
      }
    }

    // Fallback if the AI does not call the musicControl tool as expected
    console.warn('AI did not make a musicControl tool call or made an unexpected one.', {
      voiceCommand,
      response,
    });
    return {
      action: 'unhandled',
      query: voiceCommand,
      type: 'undefined',
    };
  }
);

export async function handleVoiceCommands(input: VoiceCommandInput): Promise<MusicControlAction> {
  return handleVoiceCommandsFlow(input);
}
