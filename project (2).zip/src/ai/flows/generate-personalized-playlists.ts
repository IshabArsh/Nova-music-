
'use server';
/**
 * @fileOverview A Genkit flow that generates personalized music playlists.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SongSchema = z.object({
  song_id: z.string().describe('Unique ID of the song.'),
  title: z.string().describe('Title of the song.'),
  artist: z.string().describe('Artist of the song.'),
  album: z.string().optional().describe('Album of the song.'),
  genre: z.string().optional().describe('Genre of the song.'),
});

const PlaylistSchema = z.object({
  name: z.string().describe('Name of the playlist.'),
  description: z.string().describe('Brief description.'),
  songs: z.array(SongSchema).describe('Songs in this playlist.'),
});

const PersonalizedMusicRecommendationsInputSchema = z.object({
  listeningHistorySummary: z.string().describe('Text summary of history.'),
  favoriteArtists: z.array(z.string()).describe('Favorite artists.'),
  favoriteGenres: z.array(z.string()).describe('Favorite genres.'),
  timeOfDay: z.string().describe('Current time.'),
  currentMood: z.string().optional().describe('User mood.'),
});
export type PersonalizedMusicRecommendationsInput = z.infer<typeof PersonalizedMusicRecommendationsInputSchema>;

const PersonalizedMusicRecommendationsOutputSchema = z.object({
  moodPlaylists: z.array(PlaylistSchema),
  smartPlaylists: z.array(PlaylistSchema),
  dailyDiscovery: z.array(PlaylistSchema),
});
export type PersonalizedMusicRecommendationsOutput = z.infer<typeof PersonalizedMusicRecommendationsOutputSchema>;

export async function generatePersonalizedPlaylists(input: PersonalizedMusicRecommendationsInput): Promise<PersonalizedMusicRecommendationsOutput> {
  return generatePersonalizedPlaylistsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'personalizedMusicRecommendationsPrompt',
  input: {schema: PersonalizedMusicRecommendationsInputSchema},
  output: {schema: PersonalizedMusicRecommendationsOutputSchema},
  prompt: `You are an AI music engine for "Nova Music". Generate personalized playlists.

User Data:
- History: {{{listeningHistorySummary}}}
- Artists: {{#each favoriteArtists}}{{this}}, {{/each}}
- Genres: {{#each favoriteGenres}}{{this}}, {{/each}}
- Time: {{{timeOfDay}}}
{{#if currentMood}}
- Mood: {{{currentMood}}}
{{/if}}

Create three types of playlists: Mood, Smart, and Daily Discovery.`,
});

const generatePersonalizedPlaylistsFlow = ai.defineFlow(
  {
    name: 'generatePersonalizedPlaylistsFlow',
    inputSchema: PersonalizedMusicRecommendationsInputSchema,
    outputSchema: PersonalizedMusicRecommendationsOutputSchema,
  },
  async (input) => {
    const {output} = await prompt(input);
    return output!;
  }
);
