import { config } from 'dotenv';
config();

import '@/ai/flows/generate-personalized-playlists.ts';
import '@/ai/flows/handle-voice-commands.ts';