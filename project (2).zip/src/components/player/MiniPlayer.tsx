"use client"

import { Play, Pause, SkipForward, Maximize2 } from 'lucide-react';
import Image from 'next/image';
import { useState } from 'react';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { FullPlayer } from './FullPlayer';

export function MiniPlayer() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [showFullPlayer, setShowFullPlayer] = useState(false);

  return (
    <>
      <div 
        className="w-full max-w-md mx-auto px-2 mb-2 group animate-in slide-in-from-bottom-5 fade-in duration-500"
        onClick={() => setShowFullPlayer(true)}
      >
        <div className="glass rounded-2xl p-2 flex items-center gap-3 cursor-pointer shadow-lg active:scale-[0.98] transition-all">
          <div className="relative w-12 h-12 rounded-lg overflow-hidden flex-shrink-0">
            <Image 
              src="https://picsum.photos/seed/cyber1/100/100" 
              alt="Song Cover" 
              width={48} 
              height={48} 
              className="object-cover"
            />
          </div>
          
          <div className="flex-1 min-w-0">
            <h4 className="text-sm font-semibold truncate font-headline">Neon Dreams</h4>
            <p className="text-xs text-muted-foreground truncate">Aether Flow • Pulse</p>
          </div>

          <div className="flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
            <Button variant="ghost" size="icon" className="h-8 w-8 text-foreground hover:bg-white/10" onClick={() => setIsPlaying(!isPlaying)}>
              {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current ml-0.5" />}
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8 text-foreground hover:bg-white/10">
              <SkipForward className="w-5 h-5 fill-current" />
            </Button>
          </div>
        </div>
        <Progress value={33} className="h-1 -mt-1 mx-4 bg-white/10" />
      </div>

      {showFullPlayer && <FullPlayer onClose={() => setShowFullPlayer(false)} isPlaying={isPlaying} setIsPlaying={setIsPlaying} />}
    </>
  );
}
