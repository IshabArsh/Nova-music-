
"use client"

import { ChevronDown, MoreHorizontal, Shuffle, SkipBack, Play, Pause, SkipForward, Repeat, Volume2, ListMusic, Heart, Share2, Download, Sparkles, AspectRatio, ScanLine, Maximize, Shrink } from 'lucide-react';
import Image from 'next/image';
import { Slider } from '@/components/ui/slider';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { useState, useEffect, useRef } from 'react';

interface FullPlayerProps {
  onClose: () => void;
  isPlaying: boolean;
  setIsPlaying: (playing: boolean) => void;
}

export function FullPlayer({ onClose, isPlaying, setIsPlaying }: FullPlayerProps) {
  const [mounted, setMounted] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const [isDownloaded, setIsDownloaded] = useState(false);
  const [progress, setProgress] = useState(33);
  const [currentTime, setCurrentTime] = useState(72);
  const [artMode, setArtMode] = useState<'fill' | 'fit'>('fill');
  const duration = 225;

  const longPressTimer = useRef<NodeJS.Timeout | null>(null);
  const isLongPress = useRef(false);

  useEffect(() => {
    setMounted(true);
    document.body.style.overflow = 'hidden';
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleSkip = (amount: number) => {
    setCurrentTime((prev) => {
      const newTime = Math.min(Math.max(prev + amount, 0), duration);
      setProgress((newTime / duration) * 100);
      return newTime;
    });
  };

  const startLongPress = (amount: number) => {
    isLongPress.current = false;
    longPressTimer.current = setTimeout(() => {
      isLongPress.current = true;
      const interval = setInterval(() => {
        handleSkip(amount);
      }, 100);
      longPressTimer.current = interval;
    }, 400);
  };

  const endLongPress = (onShortClick: () => void) => {
    if (longPressTimer.current) {
      if (isLongPress.current) {
        clearInterval(longPressTimer.current as any);
      } else {
        clearTimeout(longPressTimer.current as any);
        onShortClick();
      }
    }
    longPressTimer.current = null;
    isLongPress.current = false;
  };

  if (!mounted) return null;

  const currentImage = "https://picsum.photos/seed/cyber1/600/600";

  return (
    <div className="fixed inset-0 z-[100] bg-background flex flex-col animate-in slide-in-from-bottom-full duration-500 ease-out overflow-hidden">
      {/* Immersive Background */}
      <div className="absolute inset-0 z-0 overflow-hidden scale-110">
        <Image 
          src={currentImage}
          alt="Bg Base" 
          fill 
          className="object-cover opacity-60 blur-[120px] saturate-200"
        />
        <div className="absolute inset-0 bg-primary/20 blur-[150px] animate-pulse mix-blend-screen" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-background" />
      </div>

      {/* Header */}
      <header className="relative z-10 p-6 flex items-center justify-between">
        <Button variant="ghost" size="icon" onClick={onClose} className="rounded-full bg-white/10 hover:bg-white/20">
          <ChevronDown className="w-6 h-6" />
        </Button>
        <div className="text-center">
          <div className="flex items-center justify-center gap-1">
             <Sparkles className="w-3 h-3 text-primary" />
             <p className="text-[10px] uppercase tracking-widest text-white/60 font-bold">Premium Stream</p>
          </div>
          <h5 className="text-sm font-semibold truncate max-w-[150px]">Online Galaxy</h5>
        </div>
        <Button variant="ghost" size="icon" className="rounded-full bg-white/10 hover:bg-white/20">
          <MoreHorizontal className="w-6 h-6" />
        </Button>
      </header>

      {/* Album Art Section */}
      <div className="relative z-10 flex-1 flex flex-col justify-center px-8 items-center">
        <div className="relative w-full aspect-square max-w-[320px] sm:max-w-[400px] rounded-[2.5rem] overflow-hidden shadow-[0_30px_70px_-15px_rgba(0,0,0,0.8)] border border-white/10 group bg-black/40">
          <Image 
            src={currentImage}
            alt="Album Art" 
            fill 
            className={cn(
              "transition-all duration-700",
              artMode === 'fill' ? "object-cover" : "object-contain p-8"
            )}
            data-ai-hint="album art"
          />
          <div className="absolute inset-0 ring-1 ring-inset ring-white/20 rounded-[2.5rem]" />
          
          {/* Art Mode Toggle Overlay */}
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => setArtMode(artMode === 'fill' ? 'fit' : 'fill')}
            className="absolute top-4 right-4 rounded-full bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity"
          >
            {artMode === 'fill' ? <Shrink className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
          </Button>
        </div>
        
        <div className="w-full mt-12 space-y-1 max-w-[400px]">
          <div className="flex items-center justify-between gap-4">
            <div className="min-w-0">
              <h2 className="text-3xl font-headline font-bold truncate tracking-tight text-glow">Neon Dreams</h2>
              <p className="text-lg text-primary font-medium truncate opacity-90">Aether Flow • Pulse</p>
            </div>
            <Button 
              variant="ghost" 
              size="icon" 
              className={cn("rounded-full h-12 w-12 transition-all active:scale-75", isLiked ? "text-primary" : "text-white/40")}
              onClick={() => setIsLiked(!isLiked)}
            >
              <Heart className={cn("w-8 h-8", isLiked && "fill-current")} />
            </Button>
          </div>
        </div>
      </div>

      {/* Controls */}
      <footer className="relative z-10 p-8 pb-12 pt-0 space-y-8 max-w-[500px] mx-auto w-full">
        <div className="space-y-4">
          <Slider 
            value={[progress]} 
            max={100} 
            step={0.1} 
            className="py-2 cursor-pointer" 
            onValueChange={(val) => {
              setProgress(val[0]);
              setCurrentTime((val[0] / 100) * duration);
            }}
          />
          <div className="flex justify-between text-xs font-bold text-white/40 font-code tracking-widest">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>

        <div className="flex items-center justify-between">
          <Button variant="ghost" size="icon" className="text-white/40 hover:text-primary">
            <Shuffle className="w-5 h-5" />
          </Button>
          <div className="flex items-center gap-6">
            <Button 
              variant="ghost" 
              size="icon" 
              className="w-16 h-16 rounded-full hover:bg-white/5 active:scale-90 transition-all"
              onMouseDown={() => startLongPress(-5)}
              onMouseUp={() => endLongPress(() => handleSkip(-5))}
              onTouchStart={() => startLongPress(-5)}
              onTouchEnd={() => endLongPress(() => handleSkip(-5))}
            >
              <SkipBack className="w-10 h-10 fill-current" />
            </Button>
            
            <Button 
              className="w-24 h-24 rounded-full bg-primary text-primary-foreground shadow-[0_0_50px_rgba(var(--primary),0.6)] hover:scale-105 active:scale-95 transition-all"
              onClick={() => setIsPlaying(!isPlaying)}
            >
              {isPlaying ? <Pause className="w-12 h-12 fill-current" /> : <Play className="w-12 h-12 fill-current ml-1" />}
            </Button>

            <Button 
              variant="ghost" 
              size="icon" 
              className="w-16 h-16 rounded-full hover:bg-white/5 active:scale-90 transition-all"
              onMouseDown={() => startLongPress(5)}
              onMouseUp={() => endLongPress(() => handleSkip(5))}
              onTouchStart={() => startLongPress(5)}
              onTouchEnd={() => endLongPress(() => handleSkip(5))}
            >
              <SkipForward className="w-10 h-10 fill-current" />
            </Button>
          </div>
          <Button variant="ghost" size="icon" className="text-white/40 hover:text-primary">
            <Repeat className="w-5 h-5" />
          </Button>
        </div>

        <div className="flex items-center justify-between pt-2">
          <Button variant="ghost" size="icon" className="text-white/40 hover:text-primary">
            <Volume2 className="w-5 h-5" />
          </Button>
          <div className="flex gap-4">
             <Button 
              variant="ghost" 
              size="icon" 
              className={cn("text-white/40 hover:text-primary transition-colors", isDownloaded && "text-primary")}
              onClick={() => setIsDownloaded(!isDownloaded)}
            >
              <Download className="w-5 h-5" />
            </Button>
            <Button variant="ghost" size="icon" className="text-white/40 hover:text-primary">
              <ListMusic className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </footer>
    </div>
  );
}
