
"use client"

import { ChevronRight, Palette, HardDrive, ShieldCheck, Database, Music2, Headphones, Bell, Globe, Cloud, Trash2, Smartphone, LogOut } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { Progress } from '@/components/ui/progress';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { useUser, useAuth } from '@/firebase';
import { signOut } from 'firebase/auth';

export default function SettingsPage() {
  const { user } = useUser();
  const { auth } = useAuth();

  const handleLogout = () => {
    if (auth) signOut(auth);
  };

  const settingsSections = [
    {
      title: "Account & Profile",
      items: [
        { icon: Smartphone, label: "Device Management", detail: "2 Active devices", href: "/settings/devices" },
        { icon: ShieldCheck, label: "Privacy & Security", detail: "SSL Pinning Active", href: "/settings/privacy" },
        { icon: Cloud, label: "Backup & Sync", detail: "Sync with Google Drive", href: "/settings/sync" },
      ]
    },
    {
      title: "Audio Engine",
      items: [
        { icon: Headphones, label: "Playback Quality", detail: "32-bit / 192kHz", href: "/settings/audio" },
        { icon: Music2, label: "Equalizer & Effects", detail: "Bass Boost: +4dB", href: "/settings/eq" },
        { icon: Palette, label: "Theme & Styles", detail: "AMOLED Dark Mode", href: "/settings/themes" },
      ]
    },
    {
      title: "Storage & Data",
      items: [
        { icon: Database, label: "Database Management", detail: "4.2 MB Index size", href: "/settings/db" },
        { icon: Bell, label: "Smart Notifications", toggle: true, enabled: true },
        { icon: Trash2, label: "Clear Cache", detail: "Free up 240 MB", action: () => console.log('clearing') },
      ]
    }
  ];

  return (
    <div className="p-6 pb-24 max-w-2xl mx-auto space-y-8 animate-in fade-in duration-500">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-headline font-bold tracking-tight">Settings</h1>
          <p className="text-muted-foreground text-sm">v2.5.0-premium ARM64</p>
        </div>
        <Button variant="ghost" size="icon" onClick={handleLogout} className="text-destructive hover:text-destructive hover:bg-destructive/10">
          <LogOut className="w-5 h-5" />
        </Button>
      </header>

      {/* Profile Card */}
      {user && (
        <section className="glass rounded-3xl p-6 flex items-center gap-4 border-primary/20 bg-primary/5">
          <Avatar className="h-16 w-16 border-2 border-primary">
            <AvatarImage src={user.photoURL || `https://picsum.photos/seed/${user.uid}/100/100`} />
            <AvatarFallback>{user.displayName?.charAt(0)}</AvatarFallback>
          </Avatar>
          <div className="flex-1">
            <h3 className="text-lg font-bold">{user.displayName || 'Nova Member'}</h3>
            <p className="text-sm text-muted-foreground">{user.email}</p>
          </div>
          <Button variant="outline" size="sm" className="rounded-full border-primary/20">Edit</Button>
        </section>
      )}

      {/* Storage Summary Card */}
      <section className="glass rounded-3xl p-6 space-y-4 shadow-xl border-white/10">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <HardDrive className="w-5 h-5 text-primary" />
            <span className="font-semibold">Storage Management</span>
          </div>
          <span className="text-xs font-code text-muted-foreground">14.2 GB Used</span>
        </div>
        <Progress value={25} className="h-2 bg-white/5" />
        <div className="grid grid-cols-3 gap-2 text-[10px] text-muted-foreground uppercase font-bold tracking-tighter">
          <div className="flex flex-col">
            <span>Audio</span>
            <span className="text-foreground text-xs">12.8 GB</span>
          </div>
          <div className="flex flex-col">
            <span>Cache</span>
            <span className="text-foreground text-xs">1.2 GB</span>
          </div>
          <div className="flex flex-col">
            <span>DB Size</span>
            <span className="text-foreground text-xs">0.2 GB</span>
          </div>
        </div>
      </section>

      {/* Settings Sections */}
      <div className="space-y-8">
        {settingsSections.map((section) => (
          <section key={section.title} className="space-y-3">
            <h2 className="text-xs font-bold uppercase tracking-widest text-muted-foreground ml-2">{section.title}</h2>
            <div className="glass rounded-3xl overflow-hidden divide-y divide-white/5 border-white/5 shadow-lg">
              {section.items.map((item) => {
                const Icon = item.icon;
                return (
                  <div 
                    key={item.label} 
                    className="flex items-center justify-between p-4 hover:bg-white/5 transition-colors cursor-pointer group"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-muted-foreground group-hover:text-primary group-hover:bg-primary/10 transition-colors">
                        <Icon className="w-5 h-5" />
                      </div>
                      <div>
                        <p className="text-sm font-medium">{item.label}</p>
                        {item.detail && <p className="text-xs text-muted-foreground">{item.detail}</p>}
                      </div>
                    </div>
                    {item.toggle ? (
                      <Switch checked={item.enabled} />
                    ) : (
                      <ChevronRight className="w-4 h-4 text-muted-foreground" />
                    )}
                  </div>
                );
              })}
            </div>
          </section>
        ))}
      </div>

      <div className="text-center pt-4 opacity-50">
        <p className="text-[9px] font-code uppercase tracking-[0.3em]">Nova Music Premium • Secure AES-256</p>
      </div>
    </div>
  );
}
