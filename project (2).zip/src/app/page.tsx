"use client"

import { useEffect, useState, useMemo } from 'react';
import Image from 'next/image';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Play, Clock, TrendingUp, LogIn, Globe, Music } from 'lucide-react';
import { generatePersonalizedPlaylists, type PersonalizedMusicRecommendationsOutput } from '@/ai/flows/generate-personalized-playlists';
import { useAuth, useUser, useFirestore, useCollection } from '@/firebase';
import { GoogleAuthProvider, signInWithPopup, signOut } from 'firebase/auth';
import { collection, query, limit } from 'firebase/firestore';

export default function Home() {
  const { auth } = useAuth();
  const firestore = useFirestore();
  const { user, loading: userLoading } = useUser();
  const [recommendations, setRecommendations] = useState<PersonalizedMusicRecommendationsOutput | null>(null);
  const [aiLoading, setAiLoading] = useState(true);

  // Online Songs Fetching
  const songsQuery = useMemo(() => {
    if (!firestore) return null;
    return query(collection(firestore, 'songs'), limit(10));
  }, [firestore]);
  
  const { data: onlineSongs, loading: songsLoading } = useCollection(songsQuery);

  useEffect(() => {
    async function loadAIRecommendations() {
      try {
        const result = await generatePersonalizedPlaylists({
          listeningHistorySummary: "User enjoys ambient synthwave and late-night electronic pulses.",
          favoriteArtists: ['After Flow', 'Lune', 'Solaris'],
          favoriteGenres: ['Synthwave', 'Ambient', 'Techno'],
          timeOfDay: 'Evening',
          currentMood: 'Relaxed'
        });
        setRecommendations(result);
      } catch (err) {
        console.error("AI Generation failed:", err);
      } finally {
        setAiLoading(false);
      }
    }
    loadAIRecommendations();
  }, []);

  const handleLogin = async () => {
    if (!auth) return;
    const provider = new GoogleAuthProvider();
    await signInWithPopup(auth, provider);
  };

  const handleLogout = async () => {
    if (!auth) return;
    await signOut(auth);
  };

  const moods = ['Energize', 'Chill', 'Focus', 'Workout', 'Sleep', 'Party'];

  return (
    <div className="p-6 pb-20 space-y-8 max-w-2xl mx-auto">
      {/* Header */}
      <header className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-primary/20 rounded-xl">
             <Globe className="w-6 h-6 text-primary animate-pulse" />
          </div>
          <div>
            <h1 className="text-3xl font-headline font-bold tracking-tight">Nova Online</h1>
            <p className="text-muted-foreground text-sm">Streaming your sound galaxy</p>
          </div>
        </div>
        
        {user ? (
          <Avatar 
            className="h-10 w-10 border-2 border-primary/20 cursor-pointer hover:border-primary/50 transition-colors"
            onClick={handleLogout}
          >
            <AvatarImage src={user.photoURL || `https://picsum.photos/seed/${user.uid}/100/100`} />
            <AvatarFallback>{user.displayName?.charAt(0) || 'U'}</AvatarFallback>
          </Avatar>
        ) : (
          <Button variant="ghost" size="icon" onClick={handleLogin} className="rounded-full bg-white/5">
            <LogIn className="w-5 h-5" />
          </Button>
        )}
      </header>

      {!user && !userLoading && (
        <div className="glass rounded-3xl p-8 text-center space-y-4 border-primary/20 bg-primary/5">
          <Sparkles className="w-12 h-12 text-primary mx-auto" />
          <h2 className="text-xl font-bold">Sync Your Music Galaxy</h2>
          <p className="text-sm text-muted-foreground">Sign in with Google to sync your playlists and get AI-powered recommendations across all your devices.</p>
          <Button onClick={handleLogin} className="rounded-full px-8 bg-primary text-primary-foreground font-bold neon-glow">
            Connect with Google
          </Button>
        </div>
      )}

      {/* Quick Moods */}
      <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide no-scrollbar">
        {moods.map((mood) => (
          <Button 
            key={mood} 
            variant="secondary" 
            size="sm" 
            className="rounded-full bg-white/5 border border-white/10 hover:bg-primary/20 hover:text-primary transition-all flex-shrink-0"
          >
            {mood}
          </Button>
        ))}
      </div>

      {/* Featured AI Mixes */}
      <section className="space-y-4">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-primary" />
          <h2 className="text-xl font-headline font-bold tracking-tight">AI Daily Discovery</h2>
        </div>
        
        <div className="grid grid-cols-2 gap-4">
          {aiLoading ? (
            Array(4).fill(0).map((_, i) => (
              <div key={i} className="aspect-square rounded-2xl bg-white/5 animate-pulse" />
            ))
          ) : (
            recommendations?.dailyDiscovery.slice(0, 4).map((playlist, idx) => (
              <Card key={idx} className="group relative overflow-hidden border-none bg-transparent active:scale-[0.98] transition-transform cursor-pointer">
                <CardContent className="p-0">
                  <div className="relative aspect-square rounded-2xl overflow-hidden shadow-lg border border-white/5">
                    <Image 
                      src={`https://picsum.photos/seed/playlist${idx + 50}/400/400`} 
                      alt={playlist.name} 
                      fill 
                      className="object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors" />
                    <Button variant="secondary" size="icon" className="absolute bottom-3 right-3 rounded-full opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition-all shadow-xl bg-primary text-primary-foreground">
                      <Play className="w-5 h-5 fill-current ml-0.5" />
                    </Button>
                  </div>
                  <div className="mt-2 px-1">
                    <h3 className="font-semibold text-sm truncate">{playlist.name}</h3>
                    <p className="text-xs text-muted-foreground truncate">{playlist.description}</p>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </section>

      {/* Online Songs from Firestore */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Music className="w-5 h-5 text-accent" />
            <h2 className="text-xl font-headline font-bold tracking-tight">Online Library</h2>
          </div>
        </div>

        <div className="space-y-3">
          {songsLoading ? (
            Array(3).fill(0).map((_, i) => (
              <div key={i} className="flex items-center gap-4 p-2">
                <div className="w-14 h-14 rounded-lg bg-white/5 animate-pulse" />
                <div className="flex-1 space-y-2">
                  <div className="h-4 w-32 bg-white/5 animate-pulse rounded" />
                  <div className="h-3 w-20 bg-white/5 animate-pulse rounded" />
                </div>
              </div>
            ))
          ) : (
            onlineSongs.map((song: any) => (
              <div key={song.id} className="flex items-center gap-4 p-2 rounded-xl hover:bg-white/5 transition-colors cursor-pointer group">
                <div className="relative w-14 h-14 rounded-lg overflow-hidden flex-shrink-0 shadow-md">
                  <Image src={song.coverUrl || `https://picsum.photos/seed/${song.id}/100/100`} alt={song.title} fill className="object-cover" />
                  <div className="absolute inset-0 bg-black/20 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <Play className="w-6 h-6 text-white fill-current" />
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-semibold truncate">{song.title}</h4>
                  <p className="text-xs text-muted-foreground">{song.artist} • {song.album}</p>
                </div>
                <Badge variant="outline" className="text-[10px] uppercase font-bold border-primary/30 text-primary">ONLINE</Badge>
              </div>
            ))
          )}
          
          {!songsLoading && onlineSongs.length === 0 && (
            <div className="text-center py-8 glass rounded-2xl border-dashed border-white/10">
              <p className="text-muted-foreground text-sm">No online tracks found. Check your collection!</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
