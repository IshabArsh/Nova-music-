
"use client"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, FolderDown, LayoutGrid, ListFilter, Play, Plus, Download, CheckCircle2, Heart, Music2, Disc, User, Folder } from "lucide-react";
import Image from "next/image";
import { useState } from "react";
import { cn } from "@/lib/utils";

export default function LibraryPage() {
  const [activeTab, setActiveTab] = useState("Playlists");
  
  const categories = [
    { name: "Playlists", icon: Music2 },
    { name: "Artists", icon: User },
    { name: "Albums", icon: Disc },
    { name: "Folders", icon: Folder },
    { name: "Liked", icon: Heart },
  ];
  
  const items = [
    { title: "Arrival", artist: "Holographic Theory", type: "Album", img: "https://picsum.photos/seed/alb1/400/400", downloaded: true, liked: true },
    { title: "Midnight Sun", artist: "Lune", type: "Single", img: "https://picsum.photos/seed/alb2/400/400", downloaded: false, liked: false },
    { title: "Deep Space 9", artist: "Solaris", type: "Album", img: "https://picsum.photos/seed/alb3/400/400", downloaded: true, liked: true },
    { title: "Retrowave Classics", artist: "Various Artists", type: "Playlist", img: "https://picsum.photos/seed/alb4/400/400", downloaded: false, liked: false },
    { title: "Synth Waves", artist: "Aether Flow", type: "Album", img: "https://picsum.photos/seed/alb5/400/400", downloaded: true, liked: false },
    { title: "Neon Nights", artist: "Pulse", type: "Single", img: "https://picsum.photos/seed/alb6/400/400", downloaded: false, liked: true },
  ];

  const filteredItems = activeTab === "Liked" 
    ? items.filter(i => i.liked) 
    : items;

  return (
    <div className="p-6 pb-24 space-y-6 max-w-2xl mx-auto animate-in fade-in duration-700">
      <header className="flex items-center justify-between">
        <h1 className="text-3xl font-headline font-bold tracking-tight">Library</h1>
        <div className="flex gap-2">
          <Button variant="ghost" size="icon" className="rounded-full bg-white/5 hover:bg-white/10">
            <Plus className="w-6 h-6" />
          </Button>
          <Button variant="ghost" size="icon" className="rounded-full bg-white/5 hover:bg-white/10">
             <Search className="w-6 h-6" />
          </Button>
        </div>
      </header>

      <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
        {categories.map((cat) => (
          <Button 
            key={cat.name} 
            variant={activeTab === cat.name ? "default" : "outline"} 
            size="sm" 
            onClick={() => setActiveTab(cat.name)}
            className={cn(
              "rounded-full border-white/10 text-xs font-medium whitespace-nowrap gap-2 transition-all",
              activeTab === cat.name ? "bg-primary text-primary-foreground" : "hover:bg-white/5"
            )}
          >
            <cat.icon className="w-3.5 h-3.5" />
            {cat.name}
          </Button>
        ))}
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1 text-xs text-muted-foreground font-medium">
          <ListFilter className="w-4 h-4" />
          <span>Recently Added</span>
        </div>
        <div className="flex gap-4">
          <LayoutGrid className="w-4 h-4 text-primary" />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-x-4 gap-y-6">
        {filteredItems.map((item, i) => (
          <div key={i} className="group cursor-pointer">
            <div className="relative aspect-square rounded-2xl overflow-hidden shadow-lg border border-white/5">
              <Image 
                src={item.img} 
                alt={item.title} 
                fill 
                className="object-cover group-hover:scale-105 transition-transform duration-500"
                data-ai-hint="album cover"
              />
              <div className="absolute inset-0 bg-black/10 group-hover:bg-black/30 transition-colors" />
              
              <Button variant="secondary" size="icon" className="absolute bottom-3 right-3 rounded-full opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition-all shadow-xl bg-primary text-primary-foreground">
                <Play className="w-5 h-5 fill-current ml-0.5" />
              </Button>

              <div className="absolute top-2 left-2 flex gap-1.5">
                {item.downloaded && (
                  <CheckCircle2 className="w-4 h-4 text-green-400 drop-shadow-md" />
                )}
                {item.liked && (
                  <Heart className="w-4 h-4 text-primary fill-primary drop-shadow-md" />
                )}
              </div>
            </div>
            <div className="mt-3 px-1">
              <h3 className="text-sm font-semibold truncate leading-tight">{item.title}</h3>
              <p className="text-[11px] text-muted-foreground font-medium">{item.artist}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="glass rounded-3xl p-6 mt-4 flex items-center justify-between border-white/10 shadow-lg bg-primary/5">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary">
            <FolderDown className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-sm font-bold">Smart Sync</h4>
            <p className="text-xs text-muted-foreground">842 Songs backed up to cloud</p>
          </div>
        </div>
        <Button size="sm" className="rounded-full px-4 text-xs font-bold bg-primary/20 text-primary hover:bg-primary/30">View Cloud</Button>
      </div>
    </div>
  );
}
