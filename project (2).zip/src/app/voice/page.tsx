"use client"

import { useState, useEffect } from 'react';
import { Mic, X, Music, Play, SkipForward, Volume2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { handleVoiceCommands, type MusicControlAction } from '@/ai/flows/handle-voice-commands';
import { cn } from '@/lib/utils';

export default function VoicePage() {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [action, setAction] = useState<MusicControlAction | null>(null);
  const [status, setStatus] = useState("Tap the mic and say a command");

  const startListening = () => {
    setIsListening(true);
    setStatus("Listening...");
    // Simulate speech recognition
    setTimeout(() => {
      const commands = [
        "Play something relaxing",
        "Skip this track",
        "Search for After Flow",
        "Set volume to 80"
      ];
      const randomCmd = commands[Math.floor(Math.random() * commands.length)];
      setTranscript(randomCmd);
      processCommand(randomCmd);
    }, 2000);
  };

  const processCommand = async (cmd: string) => {
    setStatus("Interpreting...");
    try {
      const result = await handleVoiceCommands(cmd);
      setAction(result);
      setStatus("Command Executed");
      setTimeout(() => setIsListening(false), 2000);
    } catch (err) {
      console.error(err);
      setStatus("Error processing command");
      setIsListening(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-background/95 backdrop-blur-2xl flex flex-col items-center justify-center p-8 text-center animate-in fade-in duration-500">
      <Button 
        variant="ghost" 
        size="icon" 
        className="absolute top-8 right-8 rounded-full bg-white/5 hover:bg-white/10"
        onClick={() => window.history.back()}
      >
        <X className="w-6 h-6" />
      </Button>

      <div className="space-y-12 w-full max-w-sm">
        <header className="space-y-4">
          <div className="flex items-center justify-center gap-2 text-primary">
            <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
            <h1 className="text-sm font-bold uppercase tracking-[0.3em] font-headline">Nova Voice AI</h1>
          </div>
          <p className={cn(
            "text-2xl font-medium min-h-[3rem] transition-all",
            isListening ? "text-foreground" : "text-muted-foreground"
          )}>
            {transcript || status}
          </p>
        </header>

        {/* Visualizer Waves */}
        <div className="relative h-32 flex items-center justify-center gap-1.5">
          {isListening ? (
             [1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((i) => (
                <div 
                  key={i}
                  className="w-1.5 bg-primary/60 rounded-full animate-bounce"
                  style={{ 
                    height: `${20 + Math.random() * 80}%`,
                    animationDelay: `${i * 0.1}s`,
                    animationDuration: '0.6s'
                  }}
                />
             ))
          ) : (
            <div className="w-24 h-24 rounded-full border border-primary/20 flex items-center justify-center">
               <Mic className="w-10 h-10 text-primary/30" />
            </div>
          )}
        </div>

        <div className="space-y-8">
          <Button 
            size="lg" 
            className={cn(
              "w-24 h-24 rounded-full shadow-2xl transition-all duration-500",
              isListening 
                ? "bg-destructive text-destructive-foreground scale-90" 
                : "bg-primary text-primary-foreground neon-glow hover:scale-110 active:scale-95"
            )}
            onClick={startListening}
            disabled={isListening}
          >
            <Mic className="w-10 h-10" />
          </Button>

          <div className="grid grid-cols-2 gap-3 opacity-60">
             <div className="glass p-3 rounded-2xl flex flex-col items-center gap-2 text-[10px] font-bold uppercase tracking-tight">
                <Music className="w-4 h-4 text-primary" />
                Play Favorites
             </div>
             <div className="glass p-3 rounded-2xl flex flex-col items-center gap-2 text-[10px] font-bold uppercase tracking-tight">
                <Volume2 className="w-4 h-4 text-accent" />
                Quiet Mode
             </div>
          </div>
        </div>

        {action && (
          <div className="glass p-4 rounded-2xl animate-in slide-in-from-bottom-4 space-y-2 border-primary/20 bg-primary/5">
             <div className="flex items-center justify-center gap-2 text-primary">
                <SparklesIcon className="w-4 h-4" />
                <span className="text-xs font-bold uppercase">AI Action: {action.action}</span>
             </div>
             <p className="text-sm font-medium">{action.query ? `Searching for "${action.query}"` : "Executing command..."}</p>
          </div>
        )}
      </div>
    </div>
  );
}

function SparklesIcon(props: any) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="m12 3-1.912 5.813a2 2 0 0 1-1.275 1.275L3 12l5.813 1.912a2 2 0 0 1 1.275 1.275L12 21l1.912-5.813a2 2 0 0 1 1.275-1.275L21 12l-5.813-1.912a2 2 0 0 1-1.275-1.275L12 3Z" />
      <path d="M5 3v4" />
      <path d="M19 17v4" />
      <path d="M3 5h4" />
      <path d="M17 19h4" />
    </svg>
  );
}
