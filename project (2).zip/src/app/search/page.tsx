"use client"

import { Input } from "@/components/ui/input";
import { Search as SearchIcon, Mic, X, History, TrendingUp } from "lucide-react";
import { useState } from "react";
import Image from "next/image";

export default function SearchPage() {
  const [query, setQuery] = useState("");

  const genres = [
    { name: "Phonk", color: "bg-purple-500" },
    { name: "Lofi Beats", color: "bg-blue-400" },
    { name: "Hard Techno", color: "bg-red-500" },
    { name: "Indie Pop", color: "bg-green-400" },
    { name: "Jazz Fusion", color: "bg-amber-400" },
    { name: "Cyberpunk", color: "bg-indigo-500" },
  ];

  return (
    <div className="p-6 pb-24 max-w-2xl mx-auto space-y-8 animate-in fade-in duration-500">
      <header className="space-y-4">
        <h1 className="text-3xl font-headline font-bold tracking-tight">Search</h1>
        <div className="relative group">
          <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
            <SearchIcon className="h-5 w-5 text-muted-foreground group-focus-within:text-primary transition-colors" />
          </div>
          <Input 
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="h-14 pl-12 pr-12 rounded-2xl bg-white/5 border-white/10 focus-visible:ring-primary focus-visible:bg-white/10 text-lg transition-all"
            placeholder="Artists, songs, or podcasts"
          />
          <div className="absolute inset-y-0 right-4 flex items-center gap-2">
            {query && <X className="w-5 h-5 text-muted-foreground cursor-pointer" onClick={() => setQuery("")} />}
            <div className="w-px h-6 bg-white/10 mx-1" />
            <Mic className="h-5 w-5 text-primary cursor-pointer active:scale-90 transition-transform" />
          </div>
        </div>
      </header>

      {!query && (
        <>
          <section className="space-y-4">
            <div className="flex items-center gap-2 text-muted-foreground ml-1">
              <History className="w-4 h-4" />
              <h2 className="text-xs font-bold uppercase tracking-widest">Recent Searches</h2>
            </div>
            <div className="flex flex-wrap gap-2">
              {["Stellar Flow", "Aether Drift", "Retro Sci-Fi"].map((item) => (
                <div key={item} className="px-4 py-2 rounded-full glass border-white/5 text-sm font-medium hover:bg-white/10 cursor-pointer flex items-center gap-2">
                  {item}
                  <X className="w-3 h-3 text-muted-foreground" />
                </div>
              ))}
            </div>
          </section>

          <section className="space-y-4">
             <div className="flex items-center gap-2 text-muted-foreground ml-1">
              <TrendingUp className="w-4 h-4" />
              <h2 className="text-xs font-bold uppercase tracking-widest">Browse Genres</h2>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {genres.map((genre) => (
                <div 
                  key={genre.name} 
                  className={`relative aspect-[16/9] rounded-2xl overflow-hidden cursor-pointer group hover:scale-[1.02] transition-transform`}
                >
                  <div className={`absolute inset-0 ${genre.color} opacity-20`} />
                  <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent p-4 flex items-end">
                    <h3 className="font-headline font-bold text-lg">{genre.name}</h3>
                  </div>
                  <div className="absolute top-2 right-2 w-12 h-12 rotate-[25deg] translate-x-3 -translate-y-2 opacity-50">
                     <Image src="https://picsum.photos/seed/genre/100/100" alt="" width={48} height={48} className="rounded-lg shadow-xl" />
                  </div>
                </div>
              ))}
            </div>
          </section>
        </>
      )}

      {query && (
        <section className="space-y-4 animate-in fade-in slide-in-from-top-2">
           <h2 className="text-xs font-bold uppercase tracking-widest text-muted-foreground">Top Result</h2>
           <div className="glass rounded-3xl p-4 flex items-center gap-4 border-white/10 shadow-xl">
              <div className="relative w-20 h-20 rounded-xl overflow-hidden shadow-lg">
                <Image src="https://picsum.photos/seed/search1/200/200" alt="Result" fill className="object-cover" />
              </div>
              <div className="flex-1 min-w-0">
                <h3 className="text-xl font-bold font-headline truncate">Echoes of Time</h3>
                <p className="text-sm text-primary font-medium">Artist • Stellar Project</p>
                <div className="flex gap-1 mt-2">
                   <div className="px-2 py-0.5 glass rounded text-[9px] font-bold text-white/60">FLAC</div>
                   <div className="px-2 py-0.5 glass rounded text-[9px] font-bold text-white/60">HI-RES</div>
                </div>
              </div>
           </div>
        </section>
      )}
    </div>
  );
}
